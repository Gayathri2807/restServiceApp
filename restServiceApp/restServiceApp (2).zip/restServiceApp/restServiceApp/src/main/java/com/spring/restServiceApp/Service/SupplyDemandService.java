package com.spring.restServiceApp.Service;

import com.spring.restServiceApp.Model.Demand;
import com.spring.restServiceApp.Model.Supply;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class SupplyDemandService {

    private static List<Supply> supplyList = new ArrayList<>();
    private static List<Supply> demandList = new ArrayList<>();

    public void setSupplyList(){
        supplyList.add(new Supply("Product1",10.0));
        supplyList.add(new Supply("Product2",5.0));
    }

    public void setDemandList(){
        demandList.add(new Supply("Product1",2.0));
        demandList.add(new Supply("Product2",5.0));
    }

    public double getAvailability(String productId) {
        double demand=demandList.stream().filter(i->i.getProductId().equals(productId)).mapToDouble(i-> i.getQuantity()).sum();
        double supply=supplyList.stream().filter(i->i.getProductId().equals(productId)).mapToDouble(i->i.getQuantity()).sum();

        return(supply-demand);
    }
}
