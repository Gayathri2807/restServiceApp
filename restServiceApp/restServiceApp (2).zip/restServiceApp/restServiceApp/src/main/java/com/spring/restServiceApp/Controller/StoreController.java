package com.spring.restServiceApp.Controller;

import com.spring.restServiceApp.Model.StoreAvailability;
import com.spring.restServiceApp.Model.StoreCapacity;
import com.spring.restServiceApp.Model.StoreInput;
import com.spring.restServiceApp.Model.StoreOutput;
import com.spring.restServiceApp.Service.StoreService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;

@RestController
public class StoreController {

    @Autowired
    private StoreService storeService;

    @PostMapping("/getProdAvailability")
    public ResponseEntity<StoreOutput> getProductAvailability(@RequestBody StoreInput storeInput){
        storeService.getAvailabilityList();
        storeService.getCapacityList();

        CompletableFuture<StoreAvailability> storeAvailability = storeService.getAvailabilty(storeInput.getStoreNo());
        CompletableFuture<StoreCapacity> storeCapacity= storeService.getCapacity(storeInput.getStoreNo());
        CompletableFuture.allOf(storeAvailability,storeCapacity).join();
        String status = storeService.getStatus(storeInput.getReqDate());
        if(status.equals("No Capacity") || status.equals("No Availability") || status.equals("Available")){
            StoreOutput storeOutput = new StoreOutput(storeInput.getStoreNo(),storeInput.getProductId(),storeInput.getReqQty(),storeInput.getReqDate(),status);
            return new ResponseEntity<StoreOutput>(storeOutput, HttpStatus.OK);
        }
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }
    /*
    @PostMapping("/getProdAvailability")
    public ResponseEntity<StoreOutput> getProdAvailability(@RequestBody StoreInput storeInput) throws ExecutionException, InterruptedException {
        CompletableFuture<StoreAvailability> storeAvailability=storeService.getAvailabilty(storeInput);
        CompletableFuture<StoreCapacity> storeCapacity=storeService.getCapacity(storeOutput.getStoreNo());
        return storeService.getData(storeInput,storeAvailability.get(),storeCapacity.get());
    }

     */
}
