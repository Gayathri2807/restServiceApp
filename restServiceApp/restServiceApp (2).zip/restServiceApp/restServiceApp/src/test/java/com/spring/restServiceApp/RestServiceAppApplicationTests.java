package com.spring.restServiceApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestServiceAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
