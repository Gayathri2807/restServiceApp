package com.spring.restServiceApp.Model;

import lombok.AllArgsConstructor;
import lombok.Data;

@AllArgsConstructor
@Data
public class SupplyDemandOutput {
    private String productId;
    private Double Availability;
}
