package com.spring.restServiceApp.Model;

import lombok.AllArgsConstructor;
import lombok.Data;

@AllArgsConstructor
@Data
public class SupplyDemandInput {
    private String productId;
}
