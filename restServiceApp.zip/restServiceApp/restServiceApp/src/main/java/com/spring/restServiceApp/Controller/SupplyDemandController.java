package com.spring.restServiceApp.Controller;

import com.spring.restServiceApp.Model.SupplyDemandInput;
import com.spring.restServiceApp.Model.SupplyDemandOutput;
import com.spring.restServiceApp.Service.SupplyDemandService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class SupplyDemandController {

    @Autowired
    private SupplyDemandService supplyDemandService;

    @PostMapping("/getAvailability")
    public ResponseEntity<SupplyDemandOutput> getAvailability(@RequestBody SupplyDemandInput supplyDemandInput)
    {
        supplyDemandService.setSupplyList();
        supplyDemandService.setDemandList();

        SupplyDemandOutput suppplyDemandOutput = null;
        double availability = supplyDemandService.getAvailability(supplyDemandInput.getProductId());
        if(availability!=0)
        {
            suppplyDemandOutput = new SupplyDemandOutput(supplyDemandInput.getProductId(), availability);
            return new ResponseEntity<SupplyDemandOutput>(suppplyDemandOutput, HttpStatus.OK);
        }
        return new ResponseEntity<SupplyDemandOutput>(HttpStatus.NO_CONTENT);
    }
}
