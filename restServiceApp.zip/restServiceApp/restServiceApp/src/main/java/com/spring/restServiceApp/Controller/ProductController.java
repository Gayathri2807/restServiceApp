package com.spring.restServiceApp.Controller;

import com.spring.restServiceApp.Model.Product;
import com.spring.restServiceApp.Model.ProductList;
import com.spring.restServiceApp.Service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
public class ProductController {

    @Autowired
    private ProductService productService;

    @PostMapping("/sortProducts")
    public ResponseEntity getSortedProducts(@RequestBody ProductList productList) {
        List<Product> sortedList = productService.sortProducts(productList.getProductList());
        return  new ResponseEntity<>(sortedList, HttpStatus.OK);

    }
}
