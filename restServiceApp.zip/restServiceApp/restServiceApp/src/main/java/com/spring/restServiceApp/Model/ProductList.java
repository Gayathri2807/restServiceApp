package com.spring.restServiceApp.Model;

import lombok.Data;

import java.util.List;

@Data
public class ProductList {
    private List<Product> productList;
}
